package com.example.afinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.afinal.Usuario.DaoUsuario;
import com.example.afinal.Usuario.User;

import java.io.Closeable;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Spinner spinner;
    private Button btn;
    private TextView ed;
    private EditText cedula, contras;
    DaoUsuario dao;
    String[] items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cedula = (EditText) findViewById(R.id.txtcedula);
        contras = (EditText) findViewById(R.id.txtpassword);
        btn = (Button) findViewById(R.id.login);
        ed = (TextView) findViewById(R.id.Rt);

        btn.setOnClickListener(this);
        ed.setOnClickListener(this);
        dao = new DaoUsuario(this);
    }

    public void onClick(View v) {
        if (btn == v) {
            String u = cedula.getText().toString();
            String p = contras.getText().toString();
            if (u.equals("") && p.equals("")) {
                Toast.makeText(this, "Error: Campos vacios", Toast.LENGTH_SHORT).show();
            } else if (dao.login(u, p) == 1) {
                User ux = dao.getUsuario(u, p);
                Toast.makeText(this, "Datos correctos", Toast.LENGTH_SHORT).show();
                Intent i2 = new Intent(MainActivity.this,SplashActivity.class);
                i2.putExtra("id", ux.getId());
                startActivity(i2);
                finish();
            } else {
                Toast.makeText(this, "Usuario y/o password incorrectos", Toast.LENGTH_SHORT).show();
            }




        }
        if (ed == v) {
            Intent i2=new Intent(MainActivity.this, Registro.class);
            startActivity(i2);
            finish();

        }

    }
}



